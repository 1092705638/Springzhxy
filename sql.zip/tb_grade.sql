INSERT INTO zhxy_db.tb_grade (id, name, manager, email, telephone, introducation) VALUES (1, '一年级', '大圣', 'dasheng@163.com', '13260166090', '大学一年级');
INSERT INTO zhxy_db.tb_grade (id, name, manager, email, telephone, introducation) VALUES (2, '二年级', '小魏', 'xiaowei@163.com', '13260166090', '大学二年级');
INSERT INTO zhxy_db.tb_grade (id, name, manager, email, telephone, introducation) VALUES (3, '三年级', '小李', 'xiaoli@163.com', '13666666666', '三年级,这个班级的孩子们很有才艺');
INSERT INTO zhxy_db.tb_grade (id, name, manager, email, telephone, introducation) VALUES (4, '五年级', '小丽', 'li@123.com', '13666666666', '这个年级的同学多才多活力');
INSERT INTO zhxy_db.tb_grade (id, name, manager, email, telephone, introducation) VALUES (5, '六年级', '小明', 'xiaoming@666.com', '13666666666', '这个年级的主任是小明');
