INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (1, '一年一班', 30, '大圣的一年一班好', '大圣', 'dasheng@163.com', '13260166090', '一年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (2, '一年二班', 28, '小张的一年二班好', '小张', 'xiaozhang@163.com', '13260166090', '一年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (3, '二年一班', 35, '小韩的二年一班好', '小韩', 'xiaohan@163.com', '13260166090', '二年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (4, '二年二班', 30, '小强的二年二班好', '小强', 'xiaoqiang@163.com', '13260166090', '二年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (5, '三年一班', 30, '小花的三年一班好', '小花', 'xiaohua@163.com', '13260166090', '三年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (6, '三年二班', 30, '小赵的三年二班好', '小赵', 'xiaozhao@163.com', '13260166090', '三年级');
INSERT INTO zhxy_db.tb_clazz (id, name, number, introducation, headmaster, email, telephone, grade_name) VALUES (7, '四年一班', 30, '小赵的三年二班好', '小飞', 'xiaofei@163.com', '13260166090', '四年级');
