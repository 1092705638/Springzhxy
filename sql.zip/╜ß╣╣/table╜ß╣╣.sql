create table tb_admin
(
    id            int auto_increment
        primary key,
    name          varchar(15)  null,
    gender        char         null,
    password      varchar(100) null,
    email         varchar(50)  null,
    telephone     varchar(12)  null,
    address       varchar(100) null,
    portrait_path varchar(200) null
);

create table tb_clazz
(
    id            int auto_increment
        primary key,
    name          varchar(15)  null,
    number        int(3)       null,
    introducation varchar(200) null,
    headmaster    varchar(15)  null,
    email         varchar(50)  null,
    telephone     varchar(12)  null,
    grade_name    varchar(15)  null
);

create table tb_grade
(
    id            int auto_increment,
    name          varchar(15) default '' not null,
    manager       varchar(15)            null,
    email         varchar(50)            null,
    telephone     varchar(12)            null,
    introducation varchar(200)           null,
    primary key (id, name)
);

create table tb_student
(
    id            int auto_increment
        primary key,
    sno           varchar(20)  null,
    name          varchar(15)  null,
    gender        char         null,
    password      varchar(100) null,
    email         varchar(50)  null,
    telephone     varchar(12)  null,
    address       varchar(100) null,
    introducation varchar(200) null,
    portrait_path varchar(200) null,
    clazz_name    varchar(15)  null
);

create table tb_teacher
(
    id            int auto_increment
        primary key,
    tno           varchar(20)  null,
    name          varchar(15)  null,
    gender        char         null,
    password      varchar(100) null,
    email         varchar(50)  null,
    telephone     varchar(12)  null,
    address       varchar(100) null,
    portrait_path varchar(200) null,
    clazz_name    varchar(15)  null
);

